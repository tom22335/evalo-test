# Evalo – wersja testowa

To jest przykładowy plik README do projektu Evalo.